package com.example.demo.rest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.ADRCounterRequest;
import com.example.demo.dto.ADRCounterSuccessResponse;
import com.example.demo.util.DataBuilder;

@RestController
@RequestMapping("/cap/chnlmaint/v1")
public class ADRRest {

	private static Integer COUNTER = 0;

	@PutMapping("/dataRecipientClients/{clientId}/ADRCounters")
	public ResponseEntity<ADRCounterSuccessResponse> putADRCounters(@RequestHeader(name = "x-messageId") String messageId,
			@RequestHeader(name = "x-CorrelationId") String correlationId,
			@RequestHeader(name = "x-organisationId") String organisationId,
			@RequestHeader(name = "x-originatingSystemId") String originatindSystemId,
			@PathVariable("clientId") String clientId, @RequestBody ADRCounterRequest adrRequest) {
		COUNTER++;
		ADRCounterSuccessResponse adrCounterSuccessResponse = new ADRCounterSuccessResponse();
		adrCounterSuccessResponse
				.setData(new DataBuilder().addBrandName(adrRequest.getBrandName()).addTppClientId(clientId)
						.addCreationDateTime(adrRequest.getTransactionDateTime()).updateCount(COUNTER).get());
		return new ResponseEntity<ADRCounterSuccessResponse>(adrCounterSuccessResponse, HttpStatus.OK);
	}
}
