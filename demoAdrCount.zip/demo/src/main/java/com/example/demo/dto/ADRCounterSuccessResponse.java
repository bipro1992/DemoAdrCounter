package com.example.demo.dto;

public class ADRCounterSuccessResponse {

	private Data data;

	public Data getData() {
		return data;
	}

	public void setData(Data data) {
		this.data = data;
	}
	
	
}
