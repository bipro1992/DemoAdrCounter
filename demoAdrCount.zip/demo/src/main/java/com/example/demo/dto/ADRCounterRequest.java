package com.example.demo.dto;

import java.time.LocalDateTime;

public class ADRCounterRequest {

	private String brandName;
	
	private LocalDateTime transactionDateTime;

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public LocalDateTime getTransactionDateTime() {
		return transactionDateTime;
	}

	public void setTransactionDateTime(LocalDateTime transactionDateTime) {
		this.transactionDateTime = transactionDateTime;
	}
	
	
}
