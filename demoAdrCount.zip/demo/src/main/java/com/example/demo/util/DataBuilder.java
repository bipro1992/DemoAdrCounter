package com.example.demo.util;

import java.time.LocalDateTime;

import com.example.demo.dto.Data;

public class DataBuilder {

	private Data data;

	public DataBuilder() {
		this.data = new Data();
	}

	public DataBuilder addTppClientId(String clientId) {
		this.data.settPPClientId(clientId);
		return this;
	}

	public DataBuilder addBrandName(String brandName) {
		this.data.setBrandName(brandName);
		return this;
	}

	public DataBuilder addCreationDateTime(LocalDateTime createdDateTime) {
		this.data.setCreationDateTime(createdDateTime);
		return this;
	}

	public DataBuilder updateCount(Integer count) {
		this.data.setCounter(count);
		return this;
	}

	public Data get() {
		return this.data;
	}

}
