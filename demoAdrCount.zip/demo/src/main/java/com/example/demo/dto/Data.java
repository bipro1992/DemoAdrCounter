package com.example.demo.dto;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Data {

	@JsonProperty("TPPClientId")
	private String tPPClientId;
	
	private String brandName;
	
	private LocalDateTime creationDateTime;
	
	private Integer counter;

	public String gettPPClientId() {
		return tPPClientId;
	}

	public void settPPClientId(String tPPClientId) {
		this.tPPClientId = tPPClientId;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public LocalDateTime getCreationDateTime() {
		return creationDateTime;
	}

	public void setCreationDateTime(LocalDateTime creationDateTime) {
		this.creationDateTime = creationDateTime;
	}

	public Integer getCounter() {
		return counter;
	}

	public void setCounter(Integer counter) {
		this.counter = counter;
	}
	
	
}
